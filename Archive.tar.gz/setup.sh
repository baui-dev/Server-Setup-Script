#!/bin/bash

# Comprehensive server setup script that:
# - Sets up a fresh Debian server
# - Creates a sudo user
# - Installs Docker/Podman and Portainer
# - Configures SSH security

set -euo pipefail

# Ensure script is run as root
if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root." >&2
    exit 1
fi

# Variables
SSH_CONFIG="/etc/ssh/sshd_config"

# Source required scripts
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$DIR/ssh-setup.sh"
source "$DIR/choose-container-options.sh"
source "$DIR/setup-docker.sh"
source "$DIR/setup-podman.sh"
source "$DIR/setup-container-manager.sh"

# Function to prompt for SSH port
prompt_ssh_port() {
    local ssh_port
    while true; do
        read -p "Enter SSH port (default 22): " ssh_port
        ssh_port=${ssh_port:-22}
        
        if [[ "$ssh_port" =~ ^[0-9]+$ ]] && [[ "$ssh_port" -ge 1 ]] && [[ "$ssh_port" -le 65535 ]]; then
            echo "$ssh_port"
            break
        else
            echo "Invalid port. Please enter a number between 1 and 65535."
        fi
    done
}

# Function to setup basic firewall
setup_firewall() {
    local SSH_PORT="$1"
    
    # Install iptables-persistent
    apt-get install -y iptables-persistent
    
    # Basic firewall rules
    iptables -F
    iptables -P INPUT DROP
    iptables -P FORWARD ACCEPT
    iptables -P OUTPUT ACCEPT
    
    # Allow loopback
    iptables -A INPUT -i lo -j ACCEPT
    
    # Allow established connections
    iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    
    # Allow SSH
    iptables -A INPUT -p tcp --dport "$SSH_PORT" -j ACCEPT
    
    # Allow HTTP/HTTPS
    iptables -A INPUT -p tcp --dport 80 -j ACCEPT
    iptables -A INPUT -p tcp --dport 443 -j ACCEPT
    
    # Allow container management ports
    iptables -A INPUT -p tcp --dport 8000 -j ACCEPT  # Yacht
    iptables -A INPUT -p tcp --dport 9443 -j ACCEPT  # Portainer
    
    # Save rules
    iptables-save > /etc/iptables/rules.v4
    
    echo "Firewall configured with SSH on port $SSH_PORT"
}

# Update and upgrade the system first
echo "Updating system packages..."
apt update && apt dist-upgrade -y

# Install essential packages
apt install -y sudo curl wget apt-transport-https gnupg2 software-properties-common \
    ca-certificates lsb-release openssh-server

# Function to prompt for username and create user
create_sudo_user() {
    # Prompt for new username
    read -p "Enter new username: " NEW_USER >&2
    while [[ -z "$NEW_USER" || "$NEW_USER" == "root" ]]; do
        echo "Invalid username. Please try again." >&2
        read -p "Enter new username: " NEW_USER >&2
    done

    # Check if user already exists
    if id "$NEW_USER" &>/dev/null; then
        echo "User $NEW_USER already exists." >&2
        read -p "Do you want to set a new password for $NEW_USER? (y/n): " RESET_PASS >&2
        if [[ "$RESET_PASS" == "y" || "$RESET_PASS" == "Y" ]]; then
            passwd "$NEW_USER" >&2
        fi
    else
        # Create new user
        useradd -m -s /bin/bash "$NEW_USER"
        passwd "$NEW_USER" >&2

        # Install sudo if not present and add user to sudo group
        if ! command -v sudo &>/dev/null; then
            apt-get update && apt-get install -y sudo >&2
        fi

        usermod -aG sudo "$NEW_USER"
        echo "$NEW_USER ALL=(ALL) NOPASSWD: ALL" >/etc/sudoers.d/$NEW_USER
        chmod 0440 /etc/sudoers.d/$NEW_USER
        echo "User $NEW_USER created with sudo privileges." >&2
    fi

    # Return only the username (to stdout)
    echo "$NEW_USER"
}

# Main execution flow
echo "Starting server setup..."

# Create sudo user
echo "About to call create_sudo_user..." >&2
USER=$(create_sudo_user)
echo "Debug: Raw captured USER variable: '$USER'" >&2
# Simple validation - just ensure it's a single word
if [[ "$USER" =~ ^[a-zA-Z0-9_-]+$ ]]; then
    echo "Debug: Valid username: '$USER'" >&2
else
    echo "Debug: Invalid username format, extracting last word..." >&2
    USER=$(echo "$USER" | awk '{print $NF}')
    echo "Debug: Extracted username: '$USER'" >&2
fi
echo "Using user: $USER"

# Configure SSH security
SSH_PORT=$(prompt_ssh_port)
configure_ssh "$SSH_PORT" "$USER"

# Setup firewall
echo "Setting up firewall..."
setup_firewall "$SSH_PORT"

# Choose and install container manager
CONTAINER_ENGINE=$(choose_container_engine "$USER")

# Choose and install container UI if docker or podman was installed
if [[ "$CONTAINER_ENGINE" == "docker"* || "$CONTAINER_ENGINE" == "podman"* ]]; then
    choose_management_options "$USER" "$CONTAINER_ENGINE"
fi

# Finished
echo "Setup complete!"
echo "Your system has been configured with:"
echo "- User: $USER with sudo privileges"
echo "- SSH on port $SSH_PORT"
echo "- Basic firewall (iptables)"
echo "- Container system and management UI installed"
echo "Please reconnect to your server using: ssh $USER@your-server-ip -p $SSH_PORT"

# Prompt for reboot
read -p "Reboot now? (y/n): " REBOOT
if [[ "$REBOOT" == "y" || "$REBOOT" == "Y" ]]; then
    reboot
fi
